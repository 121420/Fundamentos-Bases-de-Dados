*********************************************************
Projeto FDB - Sistema de Gestão de Estatisticas de NBA
*********************************************************

I - Objetivo:
##    O nosso projeto é uma base de dados sobre a Liga de Basquetebol NBA, que é a principal        competição profissional de basquete do mundo.
	O objetivo é de criar uma base de dados que armazene e organize informações sobre equipas, jogadores e estatísticas, permitindo gerar relatorios e consultas.

    Queremos que a base de dados possa responder a perguntas, tais como:
    . "Quais são os jogadores de cada equipa?"
    . "Quais foram os resultados de um determinado jogo?"
    . "Quem foi o campeão em cada temporada?"
    . "Quais são as estatisticas individuais dos jogadores e ou equipas?"
    . etc...(ainda iremos especificar mais...).

    Ou seja, o nosso foco é representar a estrutura e funcionamento da NBA de forma organizada e consultável."


II - Análise de requisitos:
##  . Requisitos funcionais
        1. Registar: 
            O sistema deve permitir o registo de:
                    - equipas da NBA(Nome,cidade,treinador princial, conferência e divisão)
                    - jogadores (Nome,posicao,nacionalidade,equipa atual, altura, peso, data de nascimento)
                    - jogos (equipas participantes (casa e fora) ,data, local, resultado (pontos casa/fora), temporada)
                    - temporadas (ano de início e fim, equipe campeã, total de jogos)
                    - contratos (jogador, equipa, datas de início e fim, salário)

        2. Guardar: 
            O sistema deve guardar:
                    - estatisticas dos jogadores por jogo (pontos, assistências, ressaltos, roubos, faltas, minutos jogados, eficiência)
                    - a relação entre jogadores e equipas (contratos)
                    - o resultado de cada jogo (pontuação final e vencedor)
                    - histórico de equipas em cada temporada: posição final, número de vitórias e derrotas.

        3. Consultar:
            O sistema deve permitir consultas como: 
                    - Top scorers da época (jogadores com mais pontos)
	                - Resultados de jogos entre duas equipas específicas.
	                - estatisticas médias por jogador (pontos, ressaltos, assistências, etc...)
                    - estatisticas gerais por equipa e temporada
                    - jogadores por nacionalidade, posição ou equipa.
                    - histórico de quipas campeãs por temporada
                    - Jogadores com mais assistências, ressaltos ou eficiência
                    - evolução estatístia de um jogador ao longo das temporadas.

        4. Atualizar:
            O sistema deve permitir atualizar:
                    - tranferências de jogadores (mudança de equipa)
                    - resultados de jogos e estatisticas
                    - contratos (renovação, fim de contrato)
        
        5. Eliminar:
            O sistema deve permitir remover:
                    - equipas, jogadores, jogos, ...
                    - contratos ou estatísticas desatualizadas.

##  . Requisitos não funcionais:
        - Os dados dever ser consistentes e fáceis de Consultar.
        - O modelo deve ser escalável, podendo crescer com novas temporadas ou equipas.    

III - Principais entidades do DER e ER
    
##    Esquema Relacional (ER) com as principais entidades e atributos: 
    - Pessoa (CC(PK), nome, data_nascimento, nacionalidade, genero, email, telefone)
    - Jogador(ID_jogador(PK), CC(FK), nome_camisola, posição, altura, peso, numero, mao_dominante, ID_equipa(FK))
    - Treinador(ID_treinador(PK), CC(FK), experiencia_anos, especialidade, licenca)
    - Liga(ID_liga(PK), nome, pais, nivel)
    - Equipa(ID_equipa(PK), nome, cidade, conferência, ID_liga(FK))
    - Estadio(ID_estadio(PK), nome, cidade, capacidade, morada, ID_equipa(FK))
    - Temporada(ID_temporada(PK), ano_iniio, ano_fim, ID_liga(FK), campeao)
    - Jogo(ID_Jogo(PK), dataHora_jogo, ID_estadio(FK), ID_equipa_Casa(FK), ID_equipa_Fora(FK), pontos_casa, pontos_fora, fase, ID_temporada(FK))
    - Estatistica_Jogador_Jogo(PK(ID_jogador, ID_Jogo), minutos, pontos, assistencias, ressaltos, roubos, blocos, faltas)
    - Estatistica_Equipa_Jogo(PK(ID_equipa, ID_Jogo), pontos_totais, assistencias_totais, ressaltos_totais, faltas_totais, percentgem_lancamentos)
    - Contrato(ID_contrato(PK), data_inicio, data_fim, salario_total, clausula_rescisao, bonus_objetivos, ID_equipa(FK), CC(FK))
    - Contrato_Jogador(ID_contrato(FK e PK), ID_jogador(FK), ID_equipa(FK))
    - Contrato_Treinador(ID_contrato(FK e PK), ID_treinador(FK), ID_equipa, cargo)
    - Bilhete(ID_bilhete(PK), ID_estadio(FK), ID_Jogo(FK), setor, lugar, preco, vendido(Bool), CC(FK))

 ##   DER:
![DER diagram](DER.png "AnImage")


 ##   ER:
![ER diagram](ER.png "AnImage")
